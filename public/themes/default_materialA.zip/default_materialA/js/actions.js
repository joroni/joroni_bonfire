$(document).ready(function() {
    $("body").addClass("theme-black");
    $(".table").addClass("table-responsive");
    $(".navbar-header .bars").toggle(function() {
        $(".nav-tabs").toggleClass("hidden");
    });

    checkLoginPage();
});



function checkLoginPage() {
    if ($('#login > form').length !== 0) {
        $("body").addClass("login-page ls-closed");
        $(".container").addClass("login-box").removeClass("container");
    }
}